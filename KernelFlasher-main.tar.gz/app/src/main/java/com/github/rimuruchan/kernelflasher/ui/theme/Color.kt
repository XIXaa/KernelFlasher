package com.github.XIXaa.kernelflasher.ui.theme

import androidx.compose.ui.graphics.Color

val Orange500 = Color(0xFFFF9800)
