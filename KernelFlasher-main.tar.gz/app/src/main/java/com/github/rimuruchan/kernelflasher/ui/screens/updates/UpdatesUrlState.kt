package com.github.XIXaa.kernelflasher.ui.screens.updates

@Suppress("unused")
class UpdatesUrlState {
    // TODO: validate the url field
}