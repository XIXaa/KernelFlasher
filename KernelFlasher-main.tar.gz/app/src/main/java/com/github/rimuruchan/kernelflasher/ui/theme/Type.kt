package com.github.XIXaa.kernelflasher.ui.theme

import androidx.compose.material3.Typography

val Typography = Typography().copy()