# Kernel Flasher
Change the backup directory name to "flash _ backups" to avoid the check of some software suspicious files.

_Forked from [capntrips](https://github.com/capntrips/) and [weiishu](https://github.com/tiann)_

Kernel Flasher is an Android app to flash, backup, and restore kernels.

This fork version is fixed for KernelSu user and those who failed to flash after ota.

## Usage

`View` a slot and choose to `Flash` an AK3 zip, `Backup` the kernel related partitions, or `Restore`
a previous backup.

There are also options to toggle the mount and map status of `vendor_dlkm` and to save `dmesg`
and `logcat`.
